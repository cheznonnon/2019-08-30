// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_GAME_CHARA
#define _H_NONNON_WIN32_GAME_CHARA




#include "../neutral/bmp/all.c"

#include "../win32/win/input.c"




typedef struct {

	// main canvas : bitmap

	n_bmp *main;


	// character : bitmap

	n_bmp *chara;


	// background : bitmap or color for n_game_chara_erase()

	n_bmp *bg;
	u32    bgcolor;


	// main canvas : current position / previous position

	s32 x,y, px,py;


	// character : source position / size / margin

	s32 srcx,srcy, sx,sy, mx,my;


	// Drag And Drop

	bool dnd_onoff;
	s32  dnd_ox, dnd_oy;


	// extra data : you can use freely

	u32 data;

} n_game_chara;




#define n_game_chara_zero( c ) n_memory_zero( c, sizeof( n_game_chara ) )

inline void
n_game_chara_bmp( n_game_chara *c, n_bmp *main, n_bmp *chara, n_bmp *bg, u32 bgcolor )
{

	c->main    = main;
	c->chara   = chara;
	c->bg      = bg;
	c->bgcolor = bgcolor;


	return;
}

inline void
n_game_chara_pos( n_game_chara *c, s32 x, s32 y )
{

	c->x = x;
	c->y = y;


	return;
}

inline void
n_game_chara_prv( n_game_chara *c )
{

	c->px = c->x;
	c->py = c->y;


	return;
}

inline void
n_game_chara_src( n_game_chara *c, s32 srcx, s32 srcy, s32 sx, s32 sy, s32 mx, s32 my )
{

	c->srcx = srcx;
	c->srcy = srcy;
	c->sx   = sx;
	c->sy   = sy;
	c->mx   = mx;
	c->my   = my;


	return;
}

inline bool
n_game_chara_is_moved( const n_game_chara *c )
{

	if (
		( c->x != c->px )
		||
		( c->y != c->py )
	)
	{
		return true;
	}


	return false;
}

inline void
n_game_chara_erase( const n_game_chara *c )
{

	s32 fx  = c->px;
	s32 fy  = c->py;
	s32 fsx = c->sx;
	s32 fsy = c->sy;
	s32 tx  = fx;
	s32 ty  = fy;

	if ( c->mx ) { fx += c->mx; fsx -= c->mx * 2; tx += c->mx; }
	if ( c->my ) { fy += c->my; fsy -= c->my * 2; ty += c->my; }

	if ( c->bg == NULL )
	{
		n_bmp_box( c->main, fx,fy,fsx,fsy, c->bgcolor );
	} else {
		n_bmp_fastcopy( c->bg, c->main, fx,fy,fsx,fsy, tx,ty );
	}


	return;
}

#define n_game_chara_draw( c ) n_game_chara_draw_full( c, 0,0,0,0 )

inline void
n_game_chara_draw_full( n_game_chara *c, double blend, int mirror, int rotate, int edge )
{

	n_game_chara_prv( c );


	const bool simple = ( ( mirror == 0 )&&( rotate == 0 )&&( edge == 0 ) );


	s32 fx  = c->srcx;
	s32 fy  = c->srcy;
	s32 fsx = c->sx;
	s32 fsy = c->sy;
	s32 tx  = c->x;
	s32 ty  = c->y;

	if ( rotate == 0 )
	{
		if ( c->mx ) { fx += c->mx; fsx -= c->mx * 2; tx += c->mx; }
		if ( c->my ) { fy += c->my; fsy -= c->my * 2; ty += c->my; }
	} else {
		if ( c->mx ) { fy += c->mx; fsy -= c->mx * 2; ty += c->mx; }
		if ( c->my ) { fx += c->my; fsx -= c->my * 2; tx += c->my; }
	}

	if ( simple )
	{

		n_bmp_blendcopy( c->chara, c->main, fx,fy,fsx,fsy, tx,ty, blend );

	} else {

		if ( mirror & N_BMP_COPY_MIRROR_LEFTSIDE_RIGHT )
		{
			fx = N_BMP_SX( c->chara ) - fx - fsx;
		}

		n_bmp_copy( c->chara, c->main, fx,fy,fsx,fsy, tx,ty, blend, mirror, rotate, edge );

	}


	return;
}

#define n_game_chara_is_hit( a,b ) n_game_chara_is_hit_offset( a,b, 0,0, 0,0 )

inline bool
n_game_chara_is_hit_offset
(
	const n_game_chara *a,
	const n_game_chara *b,
	s32 a_osx, s32 a_osy,
	s32 b_osx, s32 b_osy
)
{

	// [Mechanism]
	//
	//	use n_game_chara.mx/.my for adjustment
	//	you can use *_osx and *_osy for additional margin


	s32 afx = a->x;
	s32 atx = a->x + a->sx;
	s32 bfx = b->x;
	s32 btx = b->x + b->sx;

	if ( a->mx ) { afx += a->mx; atx -= a->mx; }
	if ( a_osx ) { afx += a_osx; atx -= a_osx; }

	if ( b->mx ) { bfx += b->mx; btx -= b->mx; }
	if ( b_osx ) { bfx += b_osx; btx -= b_osx; }

	if ( afx > btx ) { return false; }
	if ( atx < bfx ) { return false; }


	s32 afy = a->y;
	s32 aty = a->y + a->sy;
	s32 bfy = b->y;
	s32 bty = b->y + b->sy;

	if ( a->my ) { afy += a->my; aty -= a->my; }
	if ( a_osy ) { afy += a_osy; aty -= a_osy; }

	if ( b->my ) { bfy += b->my; bty -= b->my; }
	if ( b_osy ) { bfy += b_osy; bty -= b_osy; }

	if ( afy > bty ) { return false; }
	if ( aty < bfy ) { return false; }


	return true;
}

#define n_game_chara_bulk_zero( c, count ) n_memory_zero( c, sizeof(n_game_chara) * (count) )

inline void
n_game_chara_bulk_bmp( n_game_chara *c, size_t count, n_bmp *main, n_bmp *chara, n_bmp *bg, u32 bgcolor )
{

	size_t i = 0;
	while( 1 )
	{

		n_game_chara_bmp( &c[ i ], main, chara, bg, bgcolor );

		i++;
		if ( i >= count ) { break; }
	}


	return;
}

inline void
n_game_chara_bulk_pos( n_game_chara *c, size_t count, s32 x, s32 y )
{

	size_t i = 0;
	while( 1 )
	{

		n_game_chara_pos( &c[ i ], x,y );

		i++;
		if ( i >= count ) { break; }
	}


	return;
}

inline void
n_game_chara_bulk_src( n_game_chara *c, size_t count, s32 srcx, s32 srcy, s32 sx, s32 sy, s32 mx, s32 my )
{

	size_t i = 0;
	while( 1 )
	{

		n_game_chara_src( &c[ i ], srcx,srcy, sx,sy, mx,my );

		i++;
		if ( i >= count ) { break; }
	}


	return;
}

inline void
n_game_chara_bulk_erase( n_game_chara *c, size_t count )
{

	size_t i = 0;
	while( 1 )
	{

		n_game_chara_erase( &c[ i ] );

		i++;
		if ( i >= count ) { break; }
	}


	return;
}

inline void
n_game_chara_bulk_draw( n_game_chara *c, size_t count )
{

	size_t i = 0;
	while( 1 )
	{

		n_game_chara_draw( &c[ i ] );

		i++;
		if ( i >= count ) { break; }
	}


	return;
}

static size_t n_game_chara_dnd_refcount = 0;

void
n_game_chara_dnd( n_game_chara *c, HWND hwnd, size_t vk )
{

	if ( c == NULL ) { return; }


	if ( n_win_is_input( vk ) )
	{
//n_win_hwndprintf_literal( hwnd, "Pressed", 0 );


		POINT pt; GetCursorPos( &pt );
		ScreenToClient( hwnd, &pt );


		n_game_chara cursor;
		n_game_chara_zero( &cursor );

		n_game_chara_pos( &cursor, pt.x,pt.y );
		n_game_chara_src( &cursor, 0,0, 1,1, 0,0 );


		if ( c->dnd_onoff == false )
		{

			if ( n_game_chara_dnd_refcount != 0 ) { return; }


			if ( n_game_chara_is_hit( &cursor, c ) )
			{
//n_win_hwndprintf_literal( hwnd, "Hit", 0 );

				n_game_chara_dnd_refcount++;

				c->dnd_onoff = true;
				c->dnd_ox    = cursor.x - c->x;
				c->dnd_oy    = cursor.y - c->y;

			}

		} else {

			pt.x -= c->dnd_ox;
			pt.y -= c->dnd_oy;

			n_game_chara_pos( c, pt.x,pt.y );

		}

	} else {
//n_win_hwndprintf_literal( hwnd, "Not Pressed", 0 );

		if ( c->dnd_onoff )
		{

			if ( n_game_chara_dnd_refcount >= 1 ) { n_game_chara_dnd_refcount--; }

			c->dnd_onoff = false;
			c->dnd_ox    = 0;
			c->dnd_oy    = 0;

		}

	}


	return;
}


#endif // _H_NONNON_WIN32_GAME_CHARA

