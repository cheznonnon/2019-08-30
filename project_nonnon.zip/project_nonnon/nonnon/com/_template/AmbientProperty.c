// Nonnon COM : IDispatch AmbientProperty
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed




#ifndef _H_NONNON_WIN32_COM_AMBIENTPROPERTY
#define _H_NONNON_WIN32_COM_AMBIENTPROPERTY




HRESULT __stdcall
n_AmbientProperty_IUnknown_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{
//N_COM_DEBUG_LISTBOX_SET_A( "n_AmbientProperty_IUnknown_QueryInterface" );


	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID d = n_com_guid( n_guid_IID_IDispatch );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &d ) )
	)
	{
//n_com_debug_IUnknown_QueryInterface( _this, iid, ppvObject );

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}




HRESULT __stdcall
n_AmbientProperty_IDispatch_Invoke
(
	void         *_this,
	DISPID        dispIdMember,
	REFIID        riid,
	LCID          lcid,
	WORD          wFlags,
	DISPPARAMS   *pDispParams,
	VARIANT      *pVarResult,
	EXCEPINFO    *pExcepInfo,
	unsigned int *puArgErr
)
{
//N_COM_DEBUG_LISTBOX_SET_A( "n_AmbientProperty_IDispatch_Invoke" );


	switch( dispIdMember ) {


	case DISPID_AMBIENT_DLCONTROL :
N_COM_DEBUG_LISTBOX_SET_A( "DISPID_AMBIENT_DLCONTROL" );

		pDispParams->rgvarg[ 0 ].lVal  = DLCTL_NO_SCRIPTS;
		pDispParams->rgvarg[ 0 ].lVal |= DLCTL_NO_JAVA;
		pDispParams->rgvarg[ 0 ].lVal |= DLCTL_NO_RUNACTIVEXCTLS | DLCTL_NO_DLACTIVEXCTLS;
		pDispParams->rgvarg[ 0 ].lVal |= DLCTL_DLIMAGES | DLCTL_VIDEOS;

n_posix_debug_literal( "Ambient" );

	break;

	case DISPID_AMBIENT_USERAGENT :
N_COM_DEBUG_LISTBOX_SET_A( "DISPID_AMBIENT_USERAGENT" );

		pDispParams->rgvarg[ 0 ].bstrVal = n_com_bstr_init_literal( "Felis" );

	break;


	default :
	{
char str[ 100 ];
sprintf( str, "DISP_E_MEMBERNOTFOUND : %08x : %d", (int) dispIdMember, (int) dispIdMember );
N_COM_DEBUG_LISTBOX_SET_A( str );

		return DISP_E_MEMBERNOTFOUND;

	}
	break;


	} // switch


	return S_OK;
}




const void *n_AmbientProperty_Vtbl[] = {

	n_AmbientProperty_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,
	n_com_IDispatch_GetTypeInfoCount,
	n_com_IDispatch_GetTypeInfo,
	n_com_IDispatch_GetIDsOfNames,
	n_AmbientProperty_IDispatch_Invoke

};


IDispatch n_AmbientProperty_instance = { (void*) n_AmbientProperty_Vtbl };




#endif // _H_NONNON_WIN32_COM_AMBIENTPROPERTY

