// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_GDI_COLOR
#define _H_NONNON_WIN32_GDI_COLOR




#include "../../neutral/bmp/color.c"


#ifndef _H_NONNON_WIN32_GDI_DOUBLEBUFFER

#include "./doublebuffer.c"

#endif // #ifndef _H_NONNON_WIN32_GDI_DOUBLEBUFFER




#define n_gdi_systemcolor( colorname ) n_gdi_colorref2argb( NULL, GetSysColor( colorname ) )

u32
n_gdi_colorref2argb( HWND hwnd, COLORREF color )
{

	n_gdi_doublebuffer db; n_gdi_doublebuffer_zero( &db );

	HDC hdc = n_gdi_doublebuffer_init( &db, hwnd, 1,1 );

	if ( db.bpp < 24 )//( db.bpp < 16 )
	{

		color = GetNearestColor( hdc, color );
		color = n_bmp_pal2rgb( color );
/*
	} else
	if ( db.bpp < 24 )
	{

		// [x] : Win9x : 32bpp to 16bpp : the system uses many conversion methods
		//
		//	GetDIBits()'d color and GetPixel()'d color will be different

		// [x] : this code is not working with 32bpp DIBSection

//n_posix_debug_literal( "%08x", color );
		SetPixel( hdc, 0,0, color );
		//color = GetPixel( hdc, 0,0 );

		n_bmp_1st_fast( &db.bmp, 1,1 );

		BITMAPINFO bi = { N_BMP_INFOH( &db.bmp ), { { 0,0,0,0 } } };
		GetDIBits( hdc, db.hbmp, 0,N_BMP_SY( &db.bmp ), N_BMP_PTR( &db.bmp ), &bi, DIB_RGB_COLORS );

		n_bmp_ptr_get_fast( &db.bmp, 0,0, &color );

		n_bmp_free( &db.bmp );

//n_posix_debug_literal( "%08x", color );
*/
	} else {

		color = n_bmp_pal2rgb( color );

	}

	n_gdi_doublebuffer_cleanup( &db );


	return n_bmp_alpha_visible_pixel( color );
}




#endif // _H_NONNON_WIN32_GDI_COLOR


