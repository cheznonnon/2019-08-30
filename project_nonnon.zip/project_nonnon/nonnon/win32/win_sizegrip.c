// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	for dark mode support only
//
//	[ WM_CREATE ]
//
//	1st : n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS,  "", &hgui_dark );
//	2nd : n_win_gui_literal( hwnd, N_WIN_GUI_VSCROLL, "", &hgui_main ); n_win_style_add( hgui_main, SBS_SIZEGRIP );
//
//	[ WndProc() ]
//
//	n_win_sizegirp_proc( ..., hgui_dark )
//
//	+ you make two controls because of flicker prevention
//	+ SetWindowPos() cannot resolve flicker, see below code




#ifndef _H_NONNON_WIN32_WIN_SIZEGRIP
#define _H_NONNON_WIN32_WIN_SIZEGRIP




#include "./gdi/doublebuffer.c"

#include "./win.c"

#include "./uxtheme.c"




void
n_win_sizegrip_status_gradient( HWND hgui, HDC hdc, s32 x, s32 y, s32 sx, s32 sy, s32 scale, COLORREF ln, COLORREF bg )
{

	s32 unit = ( 4 * scale );

	s32 oy = 0;
	while( 1 )
	{//break;

		COLORREF color = n_win_color_blend(    ln, bg, (double) oy / unit );
		         color = n_win_color_blend( color, bg,                0.5 );

		RECT r = { x, y + sy - oy - ( scale * 2 ), x + sx, y + sy - oy - ( scale * 2 ) + scale };
		n_win_box( hgui, hdc, &r, color );

		oy++;
		if ( oy >= unit ) { break; }
	}


	return;
}

s32
n_win_sizegrip_stdsize( void )
{
	return GetSystemMetrics( SM_CYHSCROLL );
}

s32
n_win_sizegrip_offset( HWND hgui )
{

	// [!] : Classic Theme : TextOut() needs stdsize, but margin will be made


	HDC hdc = GetDC( hgui );


	s32 stdsize = n_win_sizegrip_stdsize();


	HFONT  hfont = n_win_font_name2hfont( n_posix_literal( "Marlett" ), stdsize );
	HFONT phfont = SelectObject( hdc, hfont );

	n_posix_char str[ 2 ] = { 0x70, 0x00 };

	SIZE size;
	GetTextExtentPoint32( hdc, str, n_posix_strlen( str ), &size );

	SelectObject( hdc, phfont );


	ReleaseDC( hgui, hdc );


	return ( size.cy / 4 );
}

// internal
void
n_win_sizegrip_draw( HWND hgui, RECT *rect, bool statusbar_onoff )
{

	s32 x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );


	HDC hdc = n_gdi_doublebuffer_simple_init( hgui, sx,sy );


	n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme );
	n_uxtheme_init( &uxtheme, hgui, L"WINDOW" );

	if ( uxtheme.onoff )
	{

/*
		n_uxtheme_init( &uxtheme, hgui, L"SCROLLBAR" );

		int part  = 10;
		int state = 0;

		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, rect, NULL );
*/

		bool is_vista_or_later = n_sysinfo_version_vista_or_later();
		bool is_8_or_later     = n_sysinfo_version_8_or_later();


		COLORREF bg = n_win_darkmode_systemcolor( COLOR_BTNFACE   );
		COLORREF fg = n_win_darkmode_systemcolor( COLOR_BTNSHADOW );
		COLORREF ln = n_win_darkmode_systemcolor( COLOR_BTNSHADOW );

		SetBkMode( hdc, TRANSPARENT );
		n_win_box( hgui, hdc, rect, bg );

		if ( ( is_vista_or_later == false )&&( statusbar_onoff ) )
		{
			n_win_sizegrip_status_gradient( hgui, hdc, x, y, sx, sy, n_win_dpi( hgui ) / 96, ln, bg );
		}


		// [!] : "step" : Nonnon Original Behavior
		//
		//	Win32 uses always 1px for gap

		double scale = (double) n_win_dpi( hgui ) / 96;
		s32    box   = 1 + ceil( scale );
		s32    step  = box * 2;

		s32    ox    = sx - ( step * 3 ) - scale;
		s32    oy    = sy - ( step * 3 ) - scale;


		s32 cx = 0;
		s32 cy = 0;
		s32 xx = 0;
		s32 yy = 0;
		while( 1 )
		{//break;

			if ( ( yy == ( step * 0 ) )&&( xx < ( step * 2 ) ) )
			{
				//
			} else
			if ( ( yy == ( step * 1 ) )&&( xx < ( step * 1 ) ) )
			{
				//
			} else {
				if ( false == is_8_or_later )
				{
					s32 m = scale;
					RECT r = { ox+xx+m,oy+yy+m,ox+xx+m+box,oy+yy+m+box };
					n_win_box( hgui, hdc, &r, RGB( 255,255,255 ) );
				}
				RECT r = { ox+xx,oy+yy,ox+xx+box,oy+yy+box };
				n_win_box( hgui, hdc, &r, fg );
			}

			cx++;
			xx += step;
			if ( ( xx >= sx )||( cx >= 3 ) )
			{
				xx = cx = 0;
				cy++;
				yy += step;
				if ( ( yy >= sy )||( cy >= 3 ) ) { break; }
			}
		}

	} else {

//SetBkColor( hdc, RGB( 10,10,10 ) );
//DrawFrameControl( hdc, rect, DFC_SCROLL, DFCS_SCROLLSIZEGRIP );

		COLORREF bg = n_win_darkmode_systemcolor( COLOR_BTNFACE   );
		COLORREF fg = n_win_darkmode_systemcolor( COLOR_BTNSHADOW );
		COLORREF mg = n_win_darkmode_systemcolor( COLOR_WINDOW    );

		if ( n_win_darkmode_onoff )
		{
			mg = n_win_darkmode_systemcolor( COLOR_3DLIGHT );
		}

		SetBkMode( hdc, TRANSPARENT );
		n_win_box( hgui, hdc, rect, bg );

		HFONT  hfont = n_win_font_name2hfont( n_posix_literal( "Marlett" ), sx );
		HFONT phfont = SelectObject( hdc, hfont );

		n_posix_char str[ 2 ] = { 0x70, 0x00 };

		if ( ( n_win_style_is_classic() )&&( statusbar_onoff ) )
		{
			s32 o = n_win_sizegrip_offset( hgui );

			x -= o;
			y -= o;
		}

		SetTextColor( hdc, mg );
		TextOut( hdc, x-1,y-1, str, 1 );

		SetTextColor( hdc, fg );
		TextOut( hdc, x,y, str, 1 );

		SelectObject( hdc, phfont );

	}

	n_uxtheme_exit( &uxtheme, hgui );


	n_gdi_doublebuffer_simple_exit();


	return;
}

#define n_win_sizegrip_proc(           h, m, w, l, hgui ) n_win_sizegrip_proc_internal( h, m, w, l, hgui, false )
#define n_win_sizegrip_proc_statusbar( h, m, w, l, hgui ) n_win_sizegrip_proc_internal( h, m, w, l, hgui,  true )

void
n_win_sizegrip_proc_internal( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui, bool statusbar_onoff )
{

	// [x] : flicker happens with controls

	//static bool onoff = false;
	//static s32  px    = 0;
	//static s32  py    = 0;


	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( hgui != di->hwndItem ) { break; }


		n_win_sizegrip_draw( hgui, &di->rcItem, statusbar_onoff );

	}
	break;

/*
	case WM_MOUSEMOVE :

		if ( onoff )
		{

			s32 x,y; n_win_cursor_position( &x,&y );

			s32 csx,csy; n_win_size( hwnd, &csx,&csy );

			UINT swp = SWP_NOMOVE;// | SWP_NOREDRAW | SWP_NOSENDCHANGING;
			SetWindowPos( hwnd, NULL, 0,0, csx + ( x - px ), csy + ( y - py ), swp );

			px = x;
			py = y;

		}

		if ( n_win_is_hovered( hgui ) )
		{
			n_win_cursor_add( NULL, IDC_SIZENWSE );
		} else {
			n_win_cursor_add( NULL, IDC_ARROW );
		}

	break;

	case WM_LBUTTONDOWN :

		if ( n_win_is_hovered( hgui ) )
		{

			onoff = true;

			n_win_cursor_position( &px,&py );

			SetCapture( hwnd );

			n_win_cursor_add( NULL, IDC_SIZENWSE );

		}

	break;

	case WM_LBUTTONUP :

		if ( onoff )
		{
			onoff = false;

			ReleaseCapture();

			n_win_cursor_add( NULL, IDC_ARROW );
		}

	break;
*/

	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_SIZEGRIP


/*


#include "../project/macro.c"


LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui;


	switch( msg ) {


	case WM_CREATE :


		n_project_darkmode();
		//n_win_darkmode_onoff = true;


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );


		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "", &hgui );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		// Size

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		const bool redraw = true;

		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_DEFAULT );

		s32 ctl = GetSystemMetrics( SM_CYVSCROLL );
		//s32 ctl; n_win_stdsize( hgui, &ctl, NULL, NULL ); 

		n_win_move( hgui, w.csx-ctl+1,w.csy-ctl+1, ctl,ctl, redraw );

	}
	break;


	case WM_CLOSE :

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_sizegrip_proc( hwnd,msg,wparam,lparam, hgui );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

*/

