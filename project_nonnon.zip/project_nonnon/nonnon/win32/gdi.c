// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_GDI
#define _H_NONNON_WIN32_GDI




#include "../neutral/bmp/all.c"
#include "../neutral/txt.c"

#include "../game/pmr.c"
#include "../game/progressbar.c"

#include "./win/icon.c"




#define N_GDI_DEFAULT            ( 0 << 0 )
#define N_GDI_GRAY               ( 1 << 0 )
#define N_GDI_CLARITY            ( 1 << 1 )
#define N_GDI_NOMARGIN           ( 1 << 2 )
#define N_GDI_AUTOMARGIN         ( 1 << 3 )
#define N_GDI_TEXTLOADER         ( 1 << 4 )
#define N_GDI_CALCONLY           ( 1 << 5 )
#define N_GDI_PRESSED            ( 1 << 6 )
#define N_GDI_SYSTEMCOLOR        ( 1 << 7 )
#define N_GDI_LAST               N_GDI_SYSTEMCOLOR
#define N_GDI_SHADOW             ( N_GDI_LAST << 1 )
#define N_GDI_SHADOW_FOG         ( N_GDI_LAST << 2 )
#define N_GDI_CONTOUR            ( N_GDI_LAST << 3 )
#define N_GDI_CONTOUR_FOG        ( N_GDI_LAST << 4 )
#define N_GDI_SINK               ( N_GDI_LAST << 5 )
#define N_GDI_SMOOTH             ( N_GDI_LAST << 6 )

#define N_GDI_LAYOUT_HORIZONTAL  0
#define N_GDI_LAYOUT_VERTICAL    1

#define N_GDI_ALIGN_CENTER       ( 0 << 0 )
#define N_GDI_ALIGN_LEFT         ( 1 << 0 )
#define N_GDI_ALIGN_RIGHT        ( 1 << 1 )
#define N_GDI_ALIGN_TOP          ( 1 << 2 )
#define N_GDI_ALIGN_BOTTOM       ( 1 << 3 )

#define N_GDI_BASE_DEFAULT       0
#define N_GDI_BASE_SOLID         0
#define N_GDI_BASE_VERTICAL      1
#define N_GDI_BASE_HORIZONTAL    2
#define N_GDI_BASE_RECTANGLE     3
#define N_GDI_BASE_CIRCLE        4
#define N_GDI_BASE_POLKADOT      5
#define N_GDI_BASE_POLKADOT_POP  6
#define N_GDI_BASE_POLKADOT_RND  7
#define N_GDI_BASE_RECT_TILE     8
#define N_GDI_BASE_GINGHAM       9
#define N_GDI_BASE_TARTAN       10
#define N_GDI_BASE_STRIPE       11
#define N_GDI_BASE_CHECKER      12
#define N_GDI_BASE_LUNA         13
#define N_GDI_BASE_LUNA_PRESS   14
#define N_GDI_BASE_IMAGE        15
#define N_GDI_BASE_IMAGE_TILE   16
#define N_GDI_BASE_PROGRESS_H   17
#define N_GDI_BASE_PROGRESS_V   18

#define N_GDI_FRAME_DEFAULT      0
#define N_GDI_FRAME_NOFRAME      0
#define N_GDI_FRAME_TRANS        1
#define N_GDI_FRAME_SIMPLE       2
#define N_GDI_FRAME_FLAT         3
#define N_GDI_FRAME_BUTTON       4
#define N_GDI_FRAME_SCROLLARROW  5
#define N_GDI_FRAME_PUSH         6
#define N_GDI_FRAME_SINK         7
#define N_GDI_FRAME_ETCH         8
#define N_GDI_FRAME_LUNA         9
#define N_GDI_FRAME_ROUND       10
#define N_GDI_FRAME_RPG         11
#define N_GDI_FRAME_AQUA        12

#define N_GDI_FONT_DEFAULT       ( 0 << 0 )
#define N_GDI_FONT_BOLD          ( 1 << 0 )
#define N_GDI_FONT_ITALIC        ( 1 << 1 )
#define N_GDI_FONT_UNDERLINE     ( 1 << 2 )
#define N_GDI_FONT_STRIKEOUT     ( 1 << 3 )
#define N_GDI_FONT_MONOSPACE     ( 1 << 4 )

#define N_GDI_TEXT_DEFAULT       N_GDI_FONT_DEFAULT
#define N_GDI_TEXT_BOLD          N_GDI_FONT_BOLD
#define N_GDI_TEXT_ITALIC        N_GDI_FONT_ITALIC
#define N_GDI_TEXT_UNDERLINE     N_GDI_FONT_UNDERLINE
#define N_GDI_TEXT_STRIKEOUT     N_GDI_FONT_STRIKEOUT
#define N_GDI_TEXT_MONOSPACE     N_GDI_FONT_MONOSPACE
#define N_GDI_TEXT_LAST          N_GDI_TEXT_MONOSPACE
#define N_GDI_TEXT_SHADOW        ( N_GDI_TEXT_LAST << 1 )
#define N_GDI_TEXT_SHADOW_FOG    ( N_GDI_TEXT_LAST << 2 )
#define N_GDI_TEXT_CONTOUR       ( N_GDI_TEXT_LAST << 3 )
#define N_GDI_TEXT_CONTOUR_FOG   ( N_GDI_TEXT_LAST << 4 )
#define N_GDI_TEXT_SINK          ( N_GDI_TEXT_LAST << 5 )
#define N_GDI_TEXT_SMOOTH        ( N_GDI_TEXT_LAST << 6 )
#define N_GDI_TEXT_CLEAR         ( N_GDI_TEXT_LAST << 7 )
#define N_GDI_TEXT_GRADIENT      ( N_GDI_TEXT_LAST << 8 )
#define N_GDI_TEXT_ELLIPSIS      ( N_GDI_TEXT_LAST << 9 )

#define N_GDI_ICON_DEFAULT       N_GDI_TEXT_DEFAULT
#define N_GDI_ICON_SHADOW        N_GDI_TEXT_SHADOW
#define N_GDI_ICON_SHADOW_FOG    N_GDI_TEXT_SHADOW_FOG
#define N_GDI_ICON_CONTOUR       N_GDI_TEXT_CONTOUR
#define N_GDI_ICON_CONTOUR_FOG   N_GDI_TEXT_CONTOUR_FOG
#define N_GDI_ICON_SINK          N_GDI_TEXT_SINK
#define N_GDI_ICON_SMOOTH        N_GDI_TEXT_SMOOTH
#define N_GDI_ICON_LAST          N_GDI_ICON_SMOOTH
#define N_GDI_ICON_IMAGELOADER   ( N_GDI_ICON_LAST << 1 )
#define N_GDI_ICON_NOFINALIZE    ( N_GDI_ICON_LAST << 2 )
#define N_GDI_ICON_FASTMODE      ( N_GDI_ICON_LAST << 3 )
#define N_GDI_ICON_STRETCH       ( N_GDI_ICON_LAST << 4 )
#define N_GDI_ICON_RESOURCE      ( N_GDI_ICON_LAST << 5 )
#define N_GDI_ICON_RC_RESOLVE    ( N_GDI_ICON_LAST << 6 )




// [!] : auto calculation

#define N_GDI_SCALE_AUTO         ( -1 )


// [!] : use for placeholder

#define N_GDI_ICON_NAME_EMPTY    n_posix_literal( "?" )




typedef struct {

	// In

	s32           sx,sy;
	s32           scale;
	s32           style;
	s32           layout;
	s32           align;

	n_posix_char *base;
	s32           base_index;
	u32           base_color_bg;
	u32           base_color_fg;
	s32           base_style;
	s32           base_unit;

	s32           frame_style;

	n_posix_char *icon;
	s32           icon_index;
	s32           icon_style;
	u32           icon_color_shadow;
	u32           icon_color_contour;
	u32           icon_color_sink_tl;
	u32           icon_color_sink_br;
	s32           icon_fxsize1;
	s32           icon_fxsize2;

	n_posix_char *text;
	n_posix_char *text_font;
	s32           text_size;
	s32           text_style;
	u32           text_color_main;
	u32           text_color_gradient;
	u32           text_color_shadow;
	u32           text_color_contour;
	u32           text_color_sink_tl;
	u32           text_color_sink_br;
	s32           text_fxsize1;
	s32           text_fxsize2;


	// In/Out
	//
	//	icon_sx, icon_sy : zero means "auto calculation"
	//	frame_round      : only in N_GDI_FRAME_LUNA, _ROUND, _RPG and _AQUA

	s32           icon_sx, icon_sy;
	s32           frame_round;


	// Out

	s32           offset_x, offset_y;
	s32           icon_x, icon_y;
	s32           text_x, text_y, text_sx, text_sy;
	s32           frame_size;
	s32           effect_margin;


	// Internal

	HDC           hdc, hdc_compat;

	bool          pmr_onoff;

	size_t       *text_cache_len;
	SIZE         *text_cache_size;
	SIZE          text_cache_unit;
	HFONT         text_cache_hfont;
	HFONT         text_cache_pfont;
	double        text_cache_ratio;

} n_gdi;




// Constants

const int  n_gdi_smoothness = 5;


// [!] : not beautiful but GDI-independent

const bool n_gdi_fakebold_onoff = false;


// [!] : currently hidden option

static bool n_gdi_gradient_vertical_up_side_down = false;




// Components

#define n_gdi_zero(  f    ) n_memory_zero( f,    sizeof( n_gdi ) )
#define n_gdi_alias( f, t ) n_memory_copy( f, t, sizeof( n_gdi ) )


#include "./gdi/base.c"
#include "./gdi/bitmap.c"
#include "./gdi/color.c"
#include "./gdi/effect.c"
#include "./gdi/font.c"
#include "./gdi/frame.c"
#include "./gdi/icon.c"
#include "./gdi/text.c"




bool
n_gdi_base_load( const n_gdi *gdi, n_bmp *icon )
{

	if (
		( n_bmp_load   ( icon, gdi->base ) )
#ifdef _H_NONNON_NEUTRAL_PNG
		&&
		( n_png_png2bmp( gdi->base, icon ) )
#endif // #ifdef _H_NONNON_NEUTRAL_PNG
#ifdef _H_NONNON_NEUTRAL_JPG
		&&
		( n_jpg_jpg2bmp( gdi->base, icon ) )
#endif // #ifdef _H_NONNON_NEUTRAL_JPG
#ifdef _H_NONNON_WIN32_OLE_IPICTURE
		&&
		( n_IPicture_load( gdi->base, icon ) )
#endif // #ifdef _H_NONNON_WIN32_OLE_IPICTURE
	)
	{
		n_gdi_icon_extract( icon, gdi->base, gdi->base_index );
		if ( n_bmp_error( icon ) ) { return true; }
	} else {
		//return false;
	}


	return false;
}	

void
n_gdi_bmp( n_gdi *gdi, n_bmp *bmp )
{

	// [Needed] : n_gdi_zero() and n_bmp_zero()


	if ( gdi == NULL ) { return; }


	if ( gdi->sx < 0 ) { return; }
	if ( gdi->sy < 0 ) { return; }




	// Phase 1 : Initialization

	bool      onoff = ( false == ( gdi->style & N_GDI_CALCONLY ) );
	bool icon_onoff = ( false == n_string_is_empty( gdi->icon ) );
	bool text_onoff = ( false == n_string_is_empty( gdi->text ) );

	if ( ( onoff )&&( bmp == NULL ) ) { return; }


	n_txt txt; if ( text_onoff ) { n_txt_zero( &txt ); }


	gdi->hdc        = GetDC( NULL );
	gdi->hdc_compat = CreateCompatibleDC( gdi->hdc );


	// Override

	if ( gdi->scale == N_GDI_SCALE_AUTO )
	{
		gdi->scale = GetDeviceCaps( gdi->hdc, LOGPIXELSX ) / 96;
	} else {
		gdi->scale = n_posix_max_s32( 1, gdi->scale );
	}

	if ( gdi->style & N_GDI_SHADOW )
	{
		gdi->icon_style |= N_GDI_ICON_SHADOW;
		gdi->text_style |= N_GDI_TEXT_SHADOW;
	}

	if ( gdi->style & N_GDI_SHADOW_FOG )
	{
		gdi->icon_style |= N_GDI_ICON_SHADOW_FOG;
		gdi->text_style |= N_GDI_TEXT_SHADOW_FOG;
	}

	if ( gdi->style & N_GDI_CONTOUR )
	{
		gdi->icon_style |= N_GDI_ICON_CONTOUR;
		gdi->text_style |= N_GDI_TEXT_CONTOUR;
	}

	if ( gdi->style & N_GDI_CONTOUR_FOG )
	{
		gdi->icon_style |= N_GDI_ICON_CONTOUR_FOG;
		gdi->text_style |= N_GDI_TEXT_CONTOUR_FOG;
	}

	if ( gdi->style & N_GDI_SINK )
	{
		gdi->icon_style |= N_GDI_ICON_SINK;
		gdi->text_style |= N_GDI_TEXT_SINK;
	}

	if ( gdi->style & N_GDI_SMOOTH )
	{
		gdi->icon_style |= N_GDI_ICON_SMOOTH;
		gdi->text_style |= N_GDI_TEXT_SMOOTH;
	}


	// Adjustment

	//if ( gdi->text_size < 0 )
	{
		// [!] : dpi aware == false needs this
		//gdi->text_size = -MulDiv( gdi->text_size, GetDeviceCaps( gdi->hdc, LOGPIXELSY ), 72 );
	}

	if ( gdi->base_unit <= 0 )
	{
		gdi->base_unit = 64;
	}

	if ( ( n_gdi_fakebold_onoff )&&( gdi->text_style & N_GDI_TEXT_BOLD ) )
	{
		gdi->text_style |= N_GDI_TEXT_SMOOTH;
	}

	if ( gdi->text_font == NULL )
	{
		gdi->text_font = N_STRING_EMPTY;
	}

	if ( gdi->text_style & N_GDI_TEXT_CLEAR )
	{
		gdi->text_style |= N_GDI_TEXT_SMOOTH;
	}


	// Frame Border

	if ( gdi->frame_style == N_GDI_FRAME_LUNA  )
	{
		gdi->frame_round = n_posix_max_s32( 3 * gdi->scale, gdi->frame_round );
		gdi->frame_size  = n_posix_max_s32( 1 * gdi->scale, gdi->frame_size  );
	} else
	if ( gdi->frame_style == N_GDI_FRAME_ROUND )
	{
		gdi->frame_round = n_posix_max_s32( 4 * gdi->scale, gdi->frame_round );
		gdi->frame_size  = 2 * gdi->scale;
	} else
	if ( gdi->frame_style == N_GDI_FRAME_RPG   )
	{
		gdi->frame_round = n_posix_max_s32( 2 * gdi->scale, gdi->frame_round );
		gdi->frame_size  = 3 * gdi->scale;
	} else
	if ( gdi->frame_style == N_GDI_FRAME_AQUA  )
	{
		gdi->frame_round = -100;
		gdi->frame_size  = 2 * gdi->scale;
	} else
	if ( gdi->frame_style )
	{
		gdi->frame_round = 0;
		gdi->frame_size  = 2 * gdi->scale;
	} else {
		gdi->frame_round = 0;
		gdi->frame_size  = 0;
	}


	// PMR Support

	if ( n_posix_stat_is_dir( gdi->text_font ) ) { gdi->pmr_onoff = true; }

	if ( gdi->pmr_onoff )
	{
		// [!] : not supported
		if ( gdi->text_style & N_GDI_TEXT_SMOOTH )
		{
			gdi->text_style &= ~N_GDI_TEXT_SMOOTH;
		}
	}




	// Phase 2 : Size Calculation


	s32 sx = 0;
	s32 sy = 0;

	if ( icon_onoff )
	{

		// [!] : overridable

		if ( n_win_icon_init_resource_size == N_WIN_ICON_INIT_RESOURCE_SIZE_AUTO )
		{
			gdi->icon_sx = n_posix_max_s32( gdi->icon_sx, GetSystemMetrics( SM_CXICON ) );
			gdi->icon_sy = n_posix_max_s32( gdi->icon_sy, GetSystemMetrics( SM_CYICON ) );
		} else {
			gdi->icon_sx = n_posix_max_s32( gdi->icon_sx, n_win_icon_init_resource_size );
			gdi->icon_sy = n_posix_max_s32( gdi->icon_sy, n_win_icon_init_resource_size );
		}


		if ( gdi->layout == N_GDI_LAYOUT_HORIZONTAL )
		{
			sx = sx + gdi->icon_sx;
			sy = n_posix_max_s32( sy, gdi->icon_sy );
		} else
		if ( gdi->layout == N_GDI_LAYOUT_VERTICAL )
		{
			sx = n_posix_max_s32( sx, gdi->icon_sx );
			sy = sy + gdi->icon_sy;
		}

	}

	if ( text_onoff )
	{

		if (
			( false == ( gdi->style & N_GDI_TEXTLOADER ) )
			||
			( n_txt_load( &txt, gdi->text ) )
		)
		{

			// [!] : this code is single line only

			//n_txt_new( &txt );
			//n_txt_mod( &txt, 0, gdi->text );


			// [!] : don't free( s );

			n_posix_char *s = n_string_carboncopy( gdi->text );
			size_t        cb = n_string_cch2cb( s, n_posix_strlen( s ) );

//n_posix_debug_literal( "%s %d", s, cb );

			// [!] : don't use n_txt_load_onmemory()

			n_vector_load_onmemory( (void*) &txt, s, cb );

//n_memory_free( s );
//n_posix_debug_literal( "%s", txt.line[ 0 ] );

		}


		if ( gdi->frame_style == N_GDI_FRAME_AQUA )
		{
			gdi->sx -= gdi->sy;
		}

		n_gdi_text_draw( gdi, NULL, &txt, &gdi->text_sx, &gdi->text_sy );

		if ( gdi->frame_style == N_GDI_FRAME_AQUA )
		{
			gdi->sx += gdi->sy;
		}


		if ( gdi->layout == N_GDI_LAYOUT_HORIZONTAL )
		{
			sx = sx + gdi->text_sx;
			sy = n_posix_max_s32( sy, gdi->text_sy );
		} else
		if ( gdi->layout == N_GDI_LAYOUT_VERTICAL )
		{
			sx = n_posix_max_s32( sx, gdi->text_sx );
			sy = sy + gdi->text_sy;
		}

	}


	s32 border  = gdi->frame_size;
	s32 borders = border * 2;


	s32 margin = 0;

	{

		s32 icon_margin = n_posix_min_s32( gdi->icon_sx, gdi->icon_sy );
		s32 text_margin = gdi->text_size;

		if ( icon_onoff == false ) { icon_margin = 0; }
		if ( text_onoff == false ) { text_margin = 0; }

		if ( gdi->style & N_GDI_NOMARGIN )
		{
			//
		} else
		if ( gdi->style & N_GDI_AUTOMARGIN )
		{
			margin = n_posix_max_s32( icon_margin, text_margin ) / 1;
		} else
		if ( gdi->frame_style )
		{
			margin = n_posix_max_s32( icon_margin, text_margin ) / 4;
		}

	}

	s32 margins = margin * 2;


	s32 gap = 0;

	if ( ( text_onoff )&&( icon_onoff ) )
	{

		gap = margin / 2;

		if ( gdi->layout == N_GDI_LAYOUT_HORIZONTAL )
		{
			sx += gap;
		} else
		if ( gdi->layout == N_GDI_LAYOUT_VERTICAL )
		{
			sy += gap;
		}

	}


	bool is_center_x =
	(
		( gdi->align == N_GDI_ALIGN_CENTER )
		||
		(
			( false == ( gdi->align & N_GDI_ALIGN_LEFT  ) )
			&&
			( false == ( gdi->align & N_GDI_ALIGN_RIGHT ) )
		)
	);

	bool is_center_y =
	(
		( gdi->align == N_GDI_ALIGN_CENTER )
		||
		(
			( false == ( gdi->align & N_GDI_ALIGN_TOP    ) )
			&&
			( false == ( gdi->align & N_GDI_ALIGN_BOTTOM ) )
		)
	);


	s32 ox = 0;
	s32 oy = 0;

	if ( gdi->sx != 0 )
	{

		s32 base_sx = gdi->sx - ( borders + margins );

		if ( is_center_x )
		{
			ox = ( base_sx - sx ) / 2;
		} else
		if ( gdi->align & N_GDI_ALIGN_LEFT  )
		{
			ox = 0;
		} else
		if ( gdi->align & N_GDI_ALIGN_RIGHT )
		{
			ox = base_sx - sx;
		}

		sx = base_sx;

	}

	if ( gdi->sy != 0 )
	{

		s32 base_sy = gdi->sy - ( borders + margins );

		if ( is_center_y )
		{
			oy = ( base_sy - sy ) / 2;
		} else
		if ( gdi->align & N_GDI_ALIGN_TOP    )
		{
			oy = 0;
		} else
		if ( gdi->align & N_GDI_ALIGN_BOTTOM )
		{
			oy = base_sy - sy;
		}

		sy = base_sy;

	}




	// Phase 3 : Basement


	if ( ( sx <= 0 )||( sy <= 0 ) )
	{

		if ( text_onoff ) { n_txt_free( &txt ); }

		DeleteDC( gdi->hdc_compat );
		ReleaseDC( NULL, gdi->hdc );

		return;
	}


	//bool autosize_sx = ( gdi->sx == 0 );
	//bool autosize_sy = ( gdi->sy == 0 );


	gdi->sx = sx + ( borders + margins );
	gdi->sy = sy + ( borders + margins );


	n_bmp bmp_ret; n_bmp_zero( &bmp_ret );

	if ( onoff )
	{

		u32 bg = gdi->base_color_bg;
		u32 fg = gdi->base_color_fg;

		n_bmp_1st_fast( &bmp_ret, gdi->sx,gdi->sy );

		if ( gdi->base_style == N_GDI_BASE_SOLID )
		{

			n_bmp_flush( &bmp_ret, bg );

		} else
		if ( gdi->base_style == N_GDI_BASE_POLKADOT )
		{

			s32 c  = gdi->base_unit / 2;
			s32 m  = gdi->base_unit / 1;

			n_bmp_pattern_polkadot( &bmp_ret, c,m, bg,fg );

		} else
		if ( gdi->base_style == N_GDI_BASE_POLKADOT_POP )
		{

			s32 c  = gdi->base_unit / 2;
			s32 m  = gdi->base_unit / 1;

			n_bmp_pattern_polkadot_pop( &bmp_ret, c,m, bg );

		} else
		if ( gdi->base_style == N_GDI_BASE_POLKADOT_RND )
		{

			s32 c  = gdi->base_unit / 2;
			s32 m  = gdi->base_unit / 1;

			n_bmp_pattern_polkadot_rnd( &bmp_ret, c,m, bg );

		} else
		if ( gdi->base_style == N_GDI_BASE_RECT_TILE )
		{

			s32 r  = gdi->base_unit / 2;
			s32 m  = gdi->base_unit / 1;

			n_bmp_pattern_roundrect( &bmp_ret, r,m, bg, fg );

		} else
		if ( gdi->base_style == N_GDI_BASE_GINGHAM )
		{

			double strp = 0.5;
			int    shrp = 5;

			n_bmp_pattern_check( &bmp_ret, gdi->base_unit, strp, shrp, bg, fg );

		} else
		if ( gdi->base_style == N_GDI_BASE_TARTAN )
		{

			double strp = 0.25;
			int    shrp = 5;

			n_bmp_pattern_check( &bmp_ret, gdi->base_unit, strp, shrp, bg, fg );

		} else
		if ( gdi->base_style == N_GDI_BASE_STRIPE )
		{

			n_bmp_pattern_stripe( &bmp_ret, gdi->base_unit, true, bg, fg );

		} else
		if ( gdi->base_style == N_GDI_BASE_CHECKER )
		{

			n_bmp_pattern_checker( &bmp_ret, gdi->base_unit, bg, fg );

		} else
		if ( gdi->base_style == N_GDI_BASE_LUNA )
		{

			n_gdi_base_luna_solid( gdi, &bmp_ret, bg, gdi->scale );

			if ( fg != 0 )
			{

				n_bmp bmp_tmp; n_bmp_zero( &bmp_tmp ); n_bmp_1st_fast( &bmp_tmp, gdi->sx,gdi->sy );
				n_bmp_flush( &bmp_tmp, n_bmp_white_invisible );

				n_gdi_frame_roundframe_luna( gdi, &bmp_tmp, gdi->sx,gdi->sy, gdi->frame_size * 2, fg, n_bmp_white_invisible, bg, n_bmp_white_invisible, gdi->scale );

				n_bmp_flush_transcopy( &bmp_tmp, &bmp_ret );

				n_bmp_free( &bmp_tmp );

			}

		} else
		if ( gdi->base_style == N_GDI_BASE_LUNA_PRESS )
		{

			n_gdi_base_luna_press( gdi, &bmp_ret, bg, gdi->scale );

		} else
		if ( gdi->base_style == N_GDI_BASE_IMAGE )
		{

			n_gdi_base_load( gdi, &bmp_ret );

		} else
		if ( gdi->base_style == N_GDI_BASE_IMAGE_TILE )
		{

			n_gdi_base_load( gdi, &bmp_ret );
			n_bmp_resizer( &bmp_ret, gdi->sx, gdi->sy, bg, N_BMP_RESIZER_TILE );

		} else
		if ( gdi->base_style == N_GDI_BASE_PROGRESS_H )
		{

			n_bmp_flush( &bmp_ret, bg );

			n_game_progressbar_horz( &bmp_ret, 0,0,gdi->sx,gdi->sy, fg,fg, 100, gdi->sy );

			if ( n_game_progressbar_no_round )
			{
				u32 color_frame = n_bmp_blend_pixel( fg, n_bmp_rgb( 10,10,10 ), 0.125 );
				n_gdi_frame_lineframe( gdi, &bmp_ret, 0,0,gdi->sx,gdi->sy, color_frame );
			}

		} else
		if ( gdi->base_style == N_GDI_BASE_PROGRESS_V )
		{

			n_bmp_flush( &bmp_ret, bg );

			n_game_progressbar_vert( &bmp_ret, 0,0,gdi->sx,gdi->sy, fg,fg, 100, gdi->sx );

			if ( n_game_progressbar_no_round )
			{
				u32 color_frame = n_bmp_blend_pixel( fg, n_bmp_rgb( 10,10,10 ), 0.125 );
				n_gdi_frame_lineframe( gdi, &bmp_ret, 0,0,gdi->sx,gdi->sy, color_frame );
			}

		} else
		//
		{

			int mode, type;

			if ( gdi->base_style == N_GDI_BASE_CIRCLE )
			{

				mode = N_BMP_GRADIENT_CIRCLE;
				type = N_BMP_GRADIENT_CENTERING;

			} else {

				mode = N_BMP_GRADIENT_RECTANGLE;
				type = N_BMP_GRADIENT_CENTERING;

				if ( gdi->base_style == N_GDI_BASE_VERTICAL )
				{
					type = N_BMP_GRADIENT_VERTICAL;
				} else
				if ( gdi->base_style == N_GDI_BASE_HORIZONTAL )
				{
					type = N_BMP_GRADIENT_HORIZONTAL;
				}// else

			}

			n_bmp_flush_gradient( &bmp_ret, bg,fg, mode | type );

			if ( gdi->base_style == N_GDI_BASE_VERTICAL )
			{
				if ( n_gdi_gradient_vertical_up_side_down )
				{
					n_bmp_flush_mirror( &bmp_ret, N_BMP_MIRROR_UPSIDE_DOWN );
				}
			}

		}

	}




	// Phase 4 : Icon and Text


	if ( gdi->frame_style == N_GDI_FRAME_AQUA )
	{
		n_gdi_frame_draw( gdi, &bmp_ret );
	}


	if ( gdi->style & N_GDI_CLARITY )
	{
		n_gdi_frame_draw_highlight( gdi, &bmp_ret );
	}


	gdi->offset_x = ox + ( border + margin );
	gdi->offset_y = oy + ( border + margin );


//gdi->layout = N_GDI_LAYOUT_VERTICAL;
//gdi->align  = N_GDI_ALIGN_CENTER;

	if ( icon_onoff )
	{

		if ( gdi->layout == N_GDI_LAYOUT_HORIZONTAL )
		{

			gdi->icon_x = gdi->offset_x;

			if ( is_center_y )
			{
				gdi->icon_y = ( gdi->sy - gdi->icon_sy ) / 2;
			} else {
				gdi->icon_y = gdi->offset_y;
			}

		} else
		if ( gdi->layout == N_GDI_LAYOUT_VERTICAL )
		{

			if ( is_center_x )
			{
				gdi->icon_x = ( gdi->sx - gdi->icon_sx ) / 2;
			} else {
				gdi->icon_x = gdi->offset_x;
			}

			gdi->icon_y = gdi->offset_y;

		}

		if ( gdi->style & N_GDI_PRESSED )
		{
			gdi->icon_x += gdi->scale;
			gdi->icon_y += gdi->scale;
		}

		n_gdi_icon_draw( gdi, &bmp_ret );

	}

	if ( text_onoff )
	{

		if ( gdi->layout == N_GDI_LAYOUT_HORIZONTAL )
		{

			s32 icon_offset = 0;
			if ( icon_onoff ) { icon_offset = gdi->icon_sx + gap; }

			gdi->text_x = gdi->offset_x + icon_offset;

			if ( is_center_y )
			{
				gdi->text_y = ( gdi->sy - gdi->text_sy ) / 2;
			} else {
				gdi->text_y = gdi->offset_y;
			}

		} else
		if ( gdi->layout == N_GDI_LAYOUT_VERTICAL )
		{

			s32 icon_offset = 0;
			if ( icon_onoff ) { icon_offset = gdi->icon_sy + gap; }

			if ( is_center_x )
			{
				gdi->text_x = ( gdi->sx - gdi->text_sx ) / 2;
			} else {
				gdi->text_x = gdi->offset_x;
			}

			gdi->text_y = gdi->offset_y + icon_offset;

		}


		if ( gdi->frame_style == N_GDI_FRAME_AQUA )
		{
			gdi->sx -= gdi->sy;
		}

		if ( gdi->style & N_GDI_PRESSED )
		{
			gdi->text_x += gdi->scale;
			gdi->text_y += gdi->scale;
		}

		n_gdi_text_draw( gdi, &bmp_ret, &txt, NULL,NULL );

		if ( gdi->frame_style == N_GDI_FRAME_AQUA )
		{
			gdi->sx += gdi->sy;
		}

	}


	if ( gdi->style & N_GDI_GRAY )
	{
		n_bmp_flush_grayscale( &bmp_ret );
	}


	if ( gdi->frame_style != N_GDI_FRAME_AQUA )
	{
		n_gdi_frame_draw( gdi, &bmp_ret );
	}




	// Phase 5 : Cleanup

/*
	if ( gdi->text_x < 0 ) { gdi->text_sx += abs( gdi->text_x ); gdi->text_x = 0; }
	if ( gdi->text_y < 0 ) { gdi->text_sy += abs( gdi->text_y ); gdi->text_y = 0; }
n_bmp_box( &bmp_ret, gdi->text_x, gdi->text_y, gdi->text_sx, gdi->text_sy, n_bmp_white );
//n_posix_debug_literal( " %d %d %d %d ", gdi->text_x, gdi->text_y, gdi->text_sx, gdi->text_sy );
*/

	if ( onoff )
	{
		n_bmp_free_fast( bmp );
		n_bmp_alias( &bmp_ret, bmp );
	}

	if ( text_onoff ) { n_txt_free( &txt ); }

	DeleteDC( gdi->hdc_compat );
	ReleaseDC( NULL, gdi->hdc );

	gdi->hdc_compat = gdi->hdc = NULL;


	return;
}


#endif // _H_NONNON_WIN32_GDI

