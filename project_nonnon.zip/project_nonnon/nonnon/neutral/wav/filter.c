// Nonnon Nyaurism
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_WAV_FILTER
#define _H_NONNON_NEUTRAL_WAV_FILTER




#include "../random.c"


#include "./_error.c"
#include "./_piano.c"
#include "./sample.c"




#define n_wav_cosine( w, hz, r_l, r_r ) n_wav_cosine_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_cosine_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double d = n_wav_sample_cosine( hz, x + f );
		n_wav_sample_mix( wav, x + f, d, d, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_sine( w, hz, r_l, r_r ) n_wav_sine_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_sine_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double d = n_wav_sample_sine( hz, x + f );
		n_wav_sample_mix( wav, x + f, d, d, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_sawtooth( w, hz, r_l, r_r ) n_wav_sawtooth_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_sawtooth_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double d = n_wav_sample_sawtooth( hz, x + f );
		n_wav_sample_mix( wav, x + f, d, d, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_square( w, hz, r_l, r_r ) n_wav_square_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_square_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double d = n_wav_sample_square( hz, x + f );
		n_wav_sample_mix( wav, x + f, d, d, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_sandstorm( w, hz, r_l, r_r ) n_wav_sandstorm_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_sandstorm_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	n_random_shuffle();


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double d = n_wav_sample_sandstorm( hz, x + f );
		n_wav_sample_mix( wav, x + f, d, d, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_fade( w, hz, r_l, r_r ) n_wav_fade_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_fade_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double l,r, d;
		n_wav_sample_get( wav, x + f, &l, &r );

		d = (double) f / sx / 2;
		l = l * fabs( sin( N_WAV_2PI * d ) );
		r = r * fabs( sin( N_WAV_2PI * d ) );

		n_wav_sample_mix( wav, x + f, l, r, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_fade_in( w, hz, r_l, r_r ) n_wav_fade_in_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_fade_in_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t f = 0;
	size_t t = sx / 2;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double l,r, d;
		n_wav_sample_get( wav, x + f, &l, &r );

		d = (double) f / sx / 2;
		l = l * fabs( sin( N_WAV_2PI * d ) );
		r = r * fabs( sin( N_WAV_2PI * d ) );

		n_wav_sample_mix( wav, x + f, l, r, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_fade_out( w, hz, r_l, r_r ) n_wav_fade_out_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_fade_out_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t f = sx / 2;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double l,r, d;
		n_wav_sample_get( wav, x + f, &l, &r );

		d = (double) f / sx / 2;
		l = l * fabs( sin( N_WAV_2PI * d ) );
		r = r * fabs( sin( N_WAV_2PI * d ) );

		n_wav_sample_mix( wav, x + f, l, r, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_delay( w, hz, r_l, r_r ) n_wav_delay_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_delay_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t offset = (size_t) ( N_WAV_RATE( wav ) / hz );
	if ( offset >= sx ) { return; }


	n_wav w; n_wav_carboncopy( wav, &w );


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double l,r;
		n_wav_sample_get( &w, x + f, &l, &r );

		if ( n_wav_sample_is_accessible( wav, x + f + offset ) )
		{
			n_wav_sample_mix( wav, x + f + offset, l, r, ratio_l, ratio_r );
		}

		f++;

	}


	n_wav_free( &w );


	return;
}

#define n_wav_feedback_left( w, hz, r_l, r_r ) n_wav_feedback_left_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_feedback_left_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t offset = (size_t) ( N_WAV_RATE( wav ) / hz );
	if ( offset >= sx ) { return; }


	n_wav w; n_wav_carboncopy( wav, &w );


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double l,r;

		if ( n_wav_sample_is_accessible( &w, x + f + offset ) )
		{
			n_wav_sample_get( &w, x + f + offset, &l, &r );
		} else {
			l = r = 0;
		}

		n_wav_sample_mix( wav, x + f, l, r, ratio_l, ratio_r );

		f++;

	}


	n_wav_free( &w );


	return;
}

#define n_wav_feedback_right( w, hz, r_l, r_r ) n_wav_feedback_right_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_feedback_right_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t offset = (size_t) ( N_WAV_RATE( wav ) / hz );
	if ( offset >= sx ) { return; }


	n_wav w; n_wav_carboncopy( wav, &w );


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double l,r;

		if ( n_wav_sample_is_accessible( &w, x + f - offset ) )
		{
			n_wav_sample_get( &w, x + f - offset, &l, &r );
		} else {
			l = r = 0;
		}

		n_wav_sample_mix( wav, x + f, l, r, ratio_l, ratio_r );

		f++;

	}


	n_wav_free( &w );


	return;
}

#define n_wav_monaural( w, hz, r_l, r_r ) n_wav_monaural_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_monaural_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double l,r;

		n_wav_sample_get( wav, x + f, &l, &r );

		l = r = ( l + r ) / 2;

		n_wav_sample_mix( wav, x + f, l, r, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_tremolo( w, hz, r_l, r_r ) n_wav_tremolo_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_tremolo_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double d = n_wav_sample_sine_coeff( hz, x + f );

		double l,r;
		n_wav_sample_get( wav, x + f, &l, &r );

		if ( ratio_l != 0 ) { l = d * l * ratio_l; }
		if ( ratio_r != 0 ) { r = d * r * ratio_r; }

		n_wav_sample_set( wav, x + f, l, r );

		f++;

	}


	return;
}

#define n_wav_tone_up( w, hz, r_l, r_r ) n_wav_tone_up_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_tone_up_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	const size_t turn = sx / 2;


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double d = n_wav_sample_sine( n_wav_piano[ N_WAV_PIANO_MIDDLE + ( ( x + f ) > turn ) ], x + f );

		n_wav_sample_mix( wav, x + f, d, d, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_tone_down( w, hz, r_l, r_r ) n_wav_tone_down_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_tone_down_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	const size_t turn = sx / 2;


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double d = n_wav_sample_sine( n_wav_piano[ N_WAV_PIANO_MIDDLE + ( ( x + f ) < turn ) ], x + f );

		n_wav_sample_mix( wav, x + f, d, d, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_tone_updown( w, hz, r_l, r_r ) n_wav_tone_updown_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_tone_updown_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	const size_t quarter = sx / 4;


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		size_t p = x + f;
		double d;

		if ( ( p > quarter )&&( p < ( sx - quarter ) ) )
		{
			d = n_wav_sample_sine( n_wav_piano[ N_WAV_PIANO_MIDDLE + 1 ], p );
		} else {
			d = n_wav_sample_sine( n_wav_piano[ N_WAV_PIANO_MIDDLE + 0 ], p );
		}

		n_wav_sample_mix( wav, p, d, d, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_tone_downup( w, hz, r_l, r_r ) n_wav_tone_downup_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_tone_downup_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	if ( n_wav_error_format( wav ) ) { return; }


	const size_t quarter = sx / 4;


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		size_t p = x + f;
		double d;

		if ( ( p > quarter )&&( p < ( sx - quarter ) ) )
		{
			d = n_wav_sample_sine( n_wav_piano[ N_WAV_PIANO_MIDDLE + 0 ], p );
		} else {
			d = n_wav_sample_sine( n_wav_piano[ N_WAV_PIANO_MIDDLE + 1 ], p );
		}

		n_wav_sample_mix( wav, p, d, d, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_distortion( w, hz, r_l, r_r ) n_wav_distortion_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_distortion_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	// [!] : "hz" is not used


	if ( n_wav_error_format( wav ) ) { return; }


	double hi_l = 0.0;
	double hi_r = 0.0;


	// Phase 1 : get peak value

	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double l,r; n_wav_sample_get( wav, x + f, &l, &r );

		l = fabs( l );
		r = fabs( r );

		if ( hi_l < l ) { hi_l = l; }
		if ( hi_r < r ) { hi_r = r; }

		f++;

	}


	// Phase 2 : apply

	hi_l *= 1.0 - ratio_l;
	hi_r *= 1.0 - ratio_r;

	f = 0;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double l,r; n_wav_sample_get( wav, x + f, &l, &r );

		if ( fabs( l ) >= hi_l ) { if ( l > 0 ) { l = hi_l; } else { l = -hi_l; } }
		if ( fabs( r ) >= hi_r ) { if ( r > 0 ) { r = hi_r; } else { r = -hi_r; } }

		n_wav_sample_set( wav, x + f, l, r );

		f++;

	}


	return;
}

#define n_wav_normalize( w, hz, r_l, r_r ) n_wav_normalize_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_normalize_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	// [!] : "hz" is not used


	if ( n_wav_error_format( wav ) ) { return; }


	double hi_l = 0.0;
	double hi_r = 0.0;


	// Phase 1 : get peak value

	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double l,r; n_wav_sample_get( wav, x + f, &l, &r );

		l = fabs( l );
		r = fabs( r );

		if ( hi_l < l ) { hi_l = l; }
		if ( hi_r < r ) { hi_r = r; }

		f++;

	}


	// Phase 2 : apply

	double a_l = (double) N_WAV_AMP * ratio_l;
	double a_r = (double) N_WAV_AMP * ratio_r;

	f = 0;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double l,r; n_wav_sample_get( wav, x + f, &l, &r );

		if ( hi_l != 0 ) { l = a_l * ( l / hi_l ); }
		if ( hi_r != 0 ) { r = a_r * ( r / hi_r ); }

		n_wav_sample_set( wav, x + f, l, r );

		f++;

	}


	return;
}

#define n_wav_marsian( w, hz, r_l, r_r ) n_wav_marsian_partial( w, hz, 0, N_WAV_COUNT( w ), r_l, r_r )

void
n_wav_marsian_partial( n_wav *wav, double hz, size_t x, size_t sx, double ratio_l, double ratio_r )
{

	// [!] : extra-terrestrial chatter


	if ( n_wav_error_format( wav ) ) { return; }


	size_t unit = sx / N_WAV_PIANO_MAX;


	n_random_shuffle();


	size_t i = 0;
	size_t j = 0;
	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }

		double d = n_wav_sample_sine( n_wav_piano[ i ], x + f );

		j++;
		if ( j >= unit ) { i = n_random_range( N_WAV_PIANO_MAX ); j = 0; }

		n_wav_sample_mix( wav, x + f, d, d, ratio_l, ratio_r );

		f++;

	}


	return;
}

#define n_wav_smoother( w ) n_wav_smoother_partial( w, 0, N_WAV_COUNT( w ) )

void
n_wav_smoother_partial( n_wav *wav, size_t x, size_t sx )
{

	if ( n_wav_error_format( wav ) ) { return; }


	size_t count = N_WAV_COUNT( wav );


	const size_t      samples = 5;
	const size_t half_samples = samples / 2;


	size_t f = 0;
	size_t t = sx;
	while( 1 )
	{

		if ( f >= t ) { break; }


		double l = 0;
		double r = 0;

		if ( ( x + f ) >= half_samples )
		{

			size_t avr = 0;

			size_t xx = x + f - half_samples;
			while( 2 )
			{

				if ( ( xx >= 0 )&&( xx < count ) )
				{

					double ll, rr;
					n_wav_sample_get( wav, xx, &ll, &rr );

					l += ll;
					r += rr;

					avr++;

				}


				xx++;
				if ( xx > ( x + f + half_samples ) ) { break; }
			}


			l /= avr;
			r /= avr;

			n_wav_sample_set( wav, x + f, l, r );

		}


		f++;

	}


	return;
}




void
n_wav_mute( n_wav *wav, size_t x, size_t sx )
{

	if ( n_wav_error_format( wav ) ) { return; }

	size_t i = 0;
	while( 1 )
	{//break;

		if ( n_wav_sample_is_accessible( wav, x + i ) )
		{
			n_wav_sample_set( wav, x + i, 0, 0 );
		}

		i++;
		if ( i >= sx ) { break; }
	}


	return;
}

void
n_wav_delete( n_wav *wav, size_t x, size_t sx )
{

	if ( n_wav_error_format( wav ) ) { return; }


	if ( sx == 0 ) { return; }


	n_wav ret; n_wav_zero( &ret ); n_wav_new_by_sample( &ret, N_WAV_COUNT( wav ) - sx );

	size_t i = 0;
	size_t j = 0;
	while( 1 )
	{//break;

		if ( i >= x ) { break; }

		if ( i >= N_WAV_COUNT(  wav ) ) { break; }
		if ( j >= N_WAV_COUNT( &ret ) ) { break; }

		if (
			( n_wav_sample_is_accessible(  wav, i ) )
			&&
			( n_wav_sample_is_accessible( &ret, j ) )
		)
		{
			double l,r;
			n_wav_sample_get(  wav, i, &l, &r );
			n_wav_sample_set( &ret, j,  l,  r );
		}

		i++;
		j++;

	}

	i = 0;
	while( 1 )
	{//break;

		size_t pos = x + sx + i;
		if ( pos >= N_WAV_COUNT(  wav ) ) { break; }
		if (   j >= N_WAV_COUNT( &ret ) ) { break; }

		if (
			( n_wav_sample_is_accessible(  wav, pos ) )
			&&
			( n_wav_sample_is_accessible( &ret,   j ) )
		)
		{
			double l,r;
			n_wav_sample_get(  wav, pos, &l, &r );
			n_wav_sample_set( &ret,   j,  l,  r );
		}

		i++;
		j++;

	}

	n_wav_free( wav );
	n_wav_alias( &ret, wav );


	return;
}

void
n_wav_insert( n_wav *wav, n_wav *ins, size_t x, size_t sx )
{

	if ( n_wav_error_format( wav ) ) { return; }
	if ( n_wav_error_format( ins ) ) { return; }


	n_wav ret; n_wav_zero( &ret ); n_wav_new_by_sample( &ret, N_WAV_COUNT( wav ) + N_WAV_COUNT( ins ) - sx );


	size_t i = 0;
	size_t j = 0;
	while( 1 )
	{//break;

		if ( i >= x ) { break; }

		if ( i >= N_WAV_COUNT(  wav ) ) { break; }
		if ( j >= N_WAV_COUNT( &ret ) ) { break; }

		if (
			( n_wav_sample_is_accessible(  wav, i ) )
			&&
			( n_wav_sample_is_accessible( &ret, j ) )
		)
		{
			double l,r;
			n_wav_sample_get(  wav, i, &l, &r );
			n_wav_sample_set( &ret, j,  l,  r );
		}

		i++;
		j++;

	}

	i = 0;
	while( 1 )
	{//break;

		if ( i >= N_WAV_COUNT(  ins ) ) { break; }
		if ( j >= N_WAV_COUNT( &ret ) ) { break; }

		if (
			( n_wav_sample_is_accessible(  ins, i ) )
			&&
			( n_wav_sample_is_accessible( &ret, j ) )
		)
		{
			double l,r;
			n_wav_sample_get(  ins, i, &l, &r );
			n_wav_sample_set( &ret, j,  l,  r );
		}

		i++;
		j++;

	}

	i = x + sx;
	while( 1 )
	{//break;

		if ( i >= N_WAV_COUNT(  wav ) ) { break; }
		if ( j >= N_WAV_COUNT( &ret ) ) { break; }

		if (
			( n_wav_sample_is_accessible(  wav, i ) )
			&&
			( n_wav_sample_is_accessible( &ret, j ) )
		)
		{
			double l,r;
			n_wav_sample_get(  wav, i, &l, &r );
			n_wav_sample_set( &ret, j,  l,  r );
		}

		i++;
		j++;

	}


	n_wav_free( wav );
	n_wav_alias( &ret, wav );


	return;
}




#define N_WAV_COPY_SET 0
#define N_WAV_COPY_MIX 1
#define N_WAV_COPY_ADD 2

#define n_wav_set( f,t, l,r ) n_wav_copy( f,t, 0,0, 0, l,r, N_WAV_COPY_SET )
#define n_wav_mix( f,t, l,r ) n_wav_copy( f,t, 0,0, 0, l,r, N_WAV_COPY_MIX )
#define n_wav_add( f,t, l,r ) n_wav_copy( f,t, 0,0, 0, l,r, N_WAV_COPY_ADD )

void
n_wav_copy( n_wav *f, n_wav *t, size_t fx, size_t sx, size_t tx, double ratio_l, double ratio_r, int mode )
{

	if ( n_wav_error_format( f ) ) { return; }
	if ( n_wav_error_format( t ) ) { return; }


	size_t count_f = N_WAV_COUNT( f );
	size_t count_t = N_WAV_COUNT( t );

	if ( sx == 0 ) { sx = count_f; }

	if ( fx >= count_f ) { return; }
	if ( fx <        0 ) { sx += fx; tx += abs( fx ); fx = 0; }

	if ( tx >= count_t ) { return; }
	if ( tx <        0 ) { sx += tx; tx = 0; }

	if ( sx <=       0 ) { return; }


	double l, r;


	size_t x = 0;
	while( 1 )
	{//break;

		if ( ( fx + x ) >= count_f ) { break; }
		if ( ( tx + x ) >= count_t ) { break; }


		n_wav_sample_get( f, fx + x, &l, &r );

		if ( mode == N_WAV_COPY_SET )
		{
			n_wav_sample_set( t, tx + x, l * ratio_l, r * ratio_r );
		} else
		if ( mode == N_WAV_COPY_MIX )
		{
			n_wav_sample_mix( t, tx + x, l, r, ratio_l, ratio_r );
		} else
		if ( mode == N_WAV_COPY_ADD )
		{
			n_wav_sample_add( t, tx + x, l * ratio_l, r * ratio_r );
		}// else


		x++;
		if ( x >= sx ) { break; }
	}


	return;
}




#endif // _H_NONNON_NEUTRAL_WAV_FILTER

