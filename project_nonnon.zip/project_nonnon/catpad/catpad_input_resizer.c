// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// [x] : Buggy : Win10 : timer is needed

static UINT n_catpad_input_resizer_timer_id = 0;




bool
n_catpad_input_resizer_onoff( HWND hwnd, HWND hgui, s32 cursor_x, s32 cursor_y )
{

	bool ret = false;


	s32 m; n_win_stdsize( hwnd, NULL, NULL, &m );
	s32 threshold = m * 2;


	s32 x, y, sx, sy;
	n_win_location( hgui, &x, &y, &sx, &sy );

	if (
		( ( ( x - threshold ) <= cursor_x )&&( ( x += threshold ) >= cursor_x ) )
		&&
		( ( y <= cursor_y )&&( ( y + sy ) >= cursor_y ) )
	)
	{
		ret = true;
	}


	return ret;
}

bool
n_catpad_input_resizer_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui, HWND htoolband )
{

	static bool onoff = false;


	if ( ( onoff == false )&&( htoolband != n_win_cursor2hwnd_relative( hwnd ) ) ) { return false; }


	switch( msg ) {


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == n_catpad_input_resizer_timer_id )
		{

			if ( onoff == false ) { break; }


			s32 cursor_x, cursor_y;
			n_win_cursor_position_relative( n_win_hwnd_toplevel( hwnd ), &cursor_x, &cursor_y );

			s32 x,y, sx,sy;
			n_win_location( hgui, &x,&y, &sx,&sy );

//n_win_hwndprintf_literal( hwnd, " %d %d : %d %d %d %d ", cursor_x,cursor_y, x, y, sx, sy );

			s32 ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );
			n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );

			sx = n_posix_minmax( ctl * 4, w.csx - n_catpad_input_resizer_icon_sx - ( m * 2 ), w.csx - cursor_x );
			sy = ( ctl *  1 );
			 x = ( w.csx - m ) - sx;
			 y = ( ico - ctl ) / 2;

			n_win_move( hgui, x,y, sx,sy, true );


			n_catpad_input_resizer_sx = sx;

		}

	break;


	case WM_MOUSEMOVE :
	{
//n_win_hwndprintf_literal( hwnd, " WM_MOUSEMOVE " );

		s32 cursor_x, cursor_y;
		n_win_cursor_position_relative( n_win_hwnd_toplevel( hwnd ), &cursor_x, &cursor_y );

		if ( onoff )
		{

			n_win_cursor_add( NULL, IDC_SIZEWE );

		} else {

			// [Needed] : Win95 needs this position

			if ( n_catpad_input_resizer_onoff( hwnd, hgui, cursor_x, cursor_y ) )
			{
				n_win_cursor_add( NULL, IDC_SIZEWE );
			} else {
				n_win_cursor_add( NULL, IDC_ARROW );
				n_win_timer_exit( hwnd, n_catpad_input_resizer_timer_id );
			}

		}

	}
	break;


	case WM_LBUTTONDBLCLK :
	{

		s32 cursor_x, cursor_y;
		n_win_cursor_position_relative( n_win_hwnd_toplevel( hwnd ), &cursor_x, &cursor_y );

		if ( false == n_catpad_input_resizer_onoff( hwnd, hgui, cursor_x, cursor_y ) )
		{
			break;
		}


		s32 x,y, sx,sy;
		n_win_location( hgui, &x,&y, &sx,&sy );

		s32 ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );
		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );

		sx = n_posix_min_s32( ( ctl * 12 ), w.csx - n_catpad_input_resizer_icon_sx- ( m * 2 ) );;
		sy = ( ctl *  1 );
		 x = ( w.csx - m ) - sx;
		 y = ( ico - ctl ) / 2;

		n_win_move( hgui, x,y, sx,sy, true );


		n_catpad_input_resizer_sx = sx;


		n_win_location( hgui, &x,NULL, NULL,NULL );
		POINT pt = { x - m, cursor_y };
		ClientToScreen( hwnd, &pt );
		SetCursorPos( pt.x, pt.y );


		return true;
	}
	break;


	case WM_LBUTTONDOWN :
	{

		s32 cursor_x, cursor_y;
		n_win_cursor_position_relative( n_win_hwnd_toplevel( hwnd ), &cursor_x, &cursor_y );

		if ( n_catpad_input_resizer_onoff( hwnd, hgui, cursor_x, cursor_y ) )
		{
			onoff = true;
			n_win_cursor_add( NULL, IDC_SIZEWE );

			if ( n_catpad_input_resizer_timer_id == 0 ) { n_catpad_input_resizer_timer_id = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, n_catpad_input_resizer_timer_id, 1 );
		}

		SetCapture( hwnd );

	}
	break;

	case WM_LBUTTONUP :
	{

		s32 cursor_x, cursor_y;
		n_win_cursor_position_relative( n_win_hwnd_toplevel( hwnd ), &cursor_x, &cursor_y );

		if ( n_catpad_input_resizer_onoff( hwnd, hgui, cursor_x, cursor_y ) )
		{
			onoff = false;
			n_win_cursor_add( NULL, IDC_SIZEWE );
		} else {
			onoff = false;
			n_win_cursor_add( NULL, IDC_ARROW );
		}

		ReleaseCapture();

	}
	break;


	} // switch


	return false;
}


