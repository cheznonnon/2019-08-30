// Nonnon Spider
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/win_menu.c"




// internal
void
n_spider_ini_read( n_spider *p )
{

	n_ini ini; n_ini_zero( &ini );
	n_ini_load( &ini, n_project_ini_name );

	spider.option_suit = n_ini_value_int( &ini, p->ini_section, p->ini_lval_suit,  1 );

	n_ini_free( &ini );


	return;
}

// internal
void
n_spider_ini_write( n_spider *p )
{

	n_ini ini; n_ini_zero( &ini );
	n_ini_load( &ini, n_project_ini_name );

	n_ini_section_add( &ini, p->ini_section );
	n_ini_key_add_int( &ini, p->ini_section, p->ini_lval_suit, spider.option_suit );

	n_ini_save( &ini, n_project_ini_name );
	n_ini_free( &ini );


	n_explorer_refresh( false );


	return;
}




void
n_spider_subclass_sysmenu( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( false == IsWindow( hwnd ) ) { return; }


	const int menu_start = 0;
	const int menu_suit  = 2;

	static n_win_menu menu[] = {

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "Replay" ) },

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "---"    ) },

		{ N_WIN_MENU_RADIO, false, false, n_posix_literal( "1 Suit" ) },
		{ N_WIN_MENU_RADIO, false, false, n_posix_literal( "2 Suit" ) },
		{ N_WIN_MENU_RADIO, false, false, n_posix_literal( "4 Suit" ) },

		{ N_WIN_MENU_NONE,  false, false, n_posix_literal( "---"    ) },

		{ N_WIN_MENU_NONE,  false, false, NULL }

	};


	if ( spider.sysmenu_onoff == false )
	{

		spider.sysmenu_onoff = true;

		n_win_menu_system_init( hwnd, menu, menu_start );
		n_win_menu_on( menu, menu_suit + ( spider.option_suit / 2 ) );

	}


	int ret = n_win_menu_system_proc( hwnd, msg, wparam, lparam, menu, menu_start );
	if ( ret == 0 )
	{

		n_bmp_flush( &game.bmp, game.color );

		extern void n_spider_replay( n_spider* );
		n_spider_replay( &spider );

		n_game_refresh_resize();

	} else
	if ( ret >= 2 )
	{

		int offset = menu_suit;

		n_win_menu_radiobutton( menu, ret, offset, offset + 3 );

		if ( n_win_menu_is_on( menu, offset + 0 ) ) { spider.option_suit = 1; } else
		if ( n_win_menu_is_on( menu, offset + 1 ) ) { spider.option_suit = 2; } else
		if ( n_win_menu_is_on( menu, offset + 2 ) ) { spider.option_suit = 4; }

		n_spider_ini_write( &spider );

		extern void n_spider_newgame( n_spider* );
		n_spider_newgame( &spider );

	}


	return;
}

#ifndef _WIN64
static WNDPROC n_spider_subclass_pfunc = NULL;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_spider_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_spider_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		//if ( ( wparam == 0 )||( ( wparam == 67 ) ) )
		{
			SetTimer( hwnd, N_SPIDER_TIMER_ID_STYLE, 1000, NULL );
		}

	break;

	case WM_TIMER :
	{

		if ( wparam != N_SPIDER_TIMER_ID_STYLE ) { break; }

		n_win_timer_exit( hwnd, N_SPIDER_TIMER_ID_STYLE );

		extern void n_spider_style_change( n_spider* );
		n_spider_style_change( &spider );

		extern void n_spider_flush_background( n_spider* );
		n_spider_flush_background( &spider );

		extern void n_spider_redraw( n_spider* );
		n_spider_redraw( &spider );

		n_game_refresh_on();
		n_game_loop();

		n_win_message_send( game.hwnd, WM_PAINT, 0,0 );

	}
	break;


	} // switch()


	n_spider_subclass_sysmenu( hwnd,msg,wparam,lparam );

	n_win_minsize_proc( hwnd,msg,wparam,lparam, spider.cardgen.csx_min,spider.cardgen.csy_min );


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_spider_subclass_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_spider_subclass_init( n_spider *p )
{

	p->sysmenu_onoff = false;


#ifdef _WIN64

	SetWindowSubclass( game.hwnd, n_spider_subclass, 0, 0 );

#else  // #ifdef _WIN64

	// [!] : once per session

	if ( n_spider_subclass_pfunc != NULL ) { return; }

	n_spider_subclass_pfunc = n_win_gui_subclass_set( game.hwnd, n_spider_subclass );

#endif // #ifdef _WIN64


	return;
}

void
n_spider_subclass_exit( n_spider *p )
{


	p->sysmenu_onoff = false;


#ifdef _WIN64

	RemoveWindowSubclass( game.hwnd, n_spider_subclass, 0 );

#else  // #ifdef _WIN64

	if ( n_spider_subclass_pfunc == NULL ) { return; }

	n_win_gui_subclass_set( game.hwnd, n_spider_subclass_pfunc );

	n_spider_subclass_pfunc = NULL;

#endif // #ifdef _WIN64


	return;
}

