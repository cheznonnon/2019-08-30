// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : gcc4 : don't use "extern" for global "static" variables




// nonnon_paint.c

#define N_PAINT_APPNAME         "Nonnon Paint"
#define N_PAINT_APPNAME_LITERAL n_posix_literal( "Nonnon Paint" )

#define N_PAINT_MUTEX_REFRESH   n_posix_literal( "n_paint_refresh()" )


#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_NONNON_PAINT ( 0 )

#endif // #ifndef NONNON_APPS


#define N_PAINT_REFRESH_NONE     ( 0 << 0 )
#define N_PAINT_REFRESH_CLIENT   ( 1 << 0 )
#define N_PAINT_REFRESH_WINDOW   ( 1 << 1 )
#define N_PAINT_REFRESH_SCROLL   ( 1 << 2 )
#define N_PAINT_REFRESH_ALL      ( 0xffff )

#define n_paint_refresh_flush( mode ) n_paint_refresh( 0,0, N_BMP_SX( &n_paint_bmp_data ),N_BMP_SY( &n_paint_bmp_data ), mode )
#define n_paint_refresh_all()         n_paint_refresh_flush( N_PAINT_REFRESH_ALL    )
#define n_paint_refresh_client()      n_paint_refresh_flush( N_PAINT_REFRESH_CLIENT )
#define n_paint_refresh_window()      n_paint_refresh_flush( N_PAINT_REFRESH_WINDOW )
#define n_paint_refresh_scroll()      n_paint_refresh_flush( N_PAINT_REFRESH_SCROLL )


#define N_PAINT_FILTER_SCALE_LIL 0
#define N_PAINT_FILTER_SCALE_BIG 1
#define N_PAINT_FILTER_MIRROR    2
#define N_PAINT_FILTER_ROTATE_L  3
#define N_PAINT_FILTER_ROTATE_R  4
#define N_PAINT_FILTER_CLEAR     5
#define N_PAINT_FILTER_ALPHA_CLR 6
#define N_PAINT_FILTER_ALPHA_REV 7


#define N_PAINT_EXT_NUL n_posix_literal( ".___\0\0" )
#define N_PAINT_EXT_BMP n_posix_literal( ".bmp\0\0" )
#define N_PAINT_EXT_ICO n_posix_literal( ".ico\0\0" )
#define N_PAINT_EXT_CUR n_posix_literal( ".cur\0\0" )
#define N_PAINT_EXT_JPG n_posix_literal( ".jpg\0\0" )
#define N_PAINT_EXT_PNG n_posix_literal( ".png\0\0" )
#define N_PAINT_EXT_GIF n_posix_literal( ".gif\0\0" )

#define n_paint_format_is_bmp( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_BMP, name ) )
#define n_paint_format_is_ico( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_ICO, name ) )
#define n_paint_format_is_cur( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_CUR, name ) )
#define n_paint_format_is_jpg( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_JPG, name ) )
#define n_paint_format_is_png( name ) ( n_string_path_ext_is_same( N_PAINT_EXT_PNG, name ) )

#define n_paint_format_is_curico( name ) ( n_paint_format_is_ico( name ) || n_paint_format_is_cur( name ) )


// [!] : initialized by nonnon_paint_ini.c

static int          zoom;
static int          pensize, mix, edge, air;
static int          tooltype;
static bool         grid, pixelgrid, frame, antishake, graycanvas;
static int          grabber;


// [!] : initialized by nonnon_paint.c

static HWND         hwnd_main;
static HWND         hwnd_tool;
static n_win        nwin_main;
static n_win        nwin_tool;

static HBITMAP      n_paint_dibsection;
static n_bmp        n_paint_bmp_data;
static n_bmp        n_paint_bmp_grab;
static n_bmp        n_paint_bmp_dbuf;
static n_curico     n_paint_curico;

static n_posix_char *n_paint_bmpname;
static n_posix_char *n_paint_grbname;
static n_posix_char *n_paint_prvname = NULL;

static n_win_scrollbar n_paint_hscr;
static n_win_scrollbar n_paint_vscr;


#ifdef _H_NONNON_WIN32_WIN_WINTAB

static n_wintab     n_paint_wintab;
static bool         n_paint_wintab_onoff;

#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB


static s32          n_paint_prev_scrollx  = 0;
static s32          n_paint_prev_scrolly  = 0;
static HANDLE       n_paint_hmutex        = NULL;


extern void         n_paint_refresh( s32, s32, s32, s32, int );

extern void         n_paint_canvaspos( s32*, s32* );
extern void         n_paint_colorpicker( void );

extern void         n_paint_status( void );
extern void         n_paint_title( void );

extern void         n_paint_dialog_info( const n_posix_char* );
extern bool         n_paint_dialog_yesno( const n_posix_char* );

extern void         n_paint_newfile_clipboard( void );
extern bool         n_paint_load( n_posix_char*, n_bmp*, n_curico* );
extern void         n_paint_filter( int );
extern void         n_paint_filter_go( n_bmp*, int );


int
n_paint_pensize( void )
{

	int ret = pensize;

	if ( ret == 0 )
	{
		ret = 1;
	} else {
		ret = ( ret * 2 ) + 1;
	}

	return ret;
}


// [!] : canvas helper

#define N_PAINT_CANVAS_COLOR  n_bmp_rgb( 128,128,128 )
#define N_PAINT_CANVAS_SIZE   128
#define N_PAINT_CANVAS_MARGIN  32

inline void
n_paint_margin_get( s32 *sx, s32 *sy )
{

	double scale  = (double) n_win_dpi( hwnd_main ) / 96.0;
	double margin = (double) N_PAINT_CANVAS_MARGIN * scale;

	//if ( n_direct2d_is_on() ) { margin = 0; }

	if ( sx != NULL ) { (*sx) = trunc( margin ); }
	if ( sy != NULL ) { (*sy) = trunc( margin ); }


	return;
}


// [!] : zoom in/out support helper

#define N_PAINT_ZOOM_MAX  ( 200 )
#define N_PAINT_ZOOM_ZERO ( N_PAINT_ZOOM_MAX / 2 )

#define n_paint_is_zoom_in(  zoom ) ( zoom > N_PAINT_ZOOM_ZERO )
#define n_paint_is_zoom_out( zoom ) ( zoom < N_PAINT_ZOOM_ZERO )

int
n_paint_zoom_get( int zoom )
{

	if ( n_paint_is_zoom_in( zoom ) )
	{
		return ( zoom - N_PAINT_ZOOM_ZERO );
	} else
	if ( n_paint_is_zoom_out( zoom ) )
	{
		return ( N_PAINT_ZOOM_ZERO - zoom );
	}


	return 0;
}

int
n_paint_zoom_clamp( int prev, int zoom )
{

	if ( prev > N_PAINT_ZOOM_ZERO )
	{
		if ( zoom < ( N_PAINT_ZOOM_ZERO + 1 ) ) { zoom = N_PAINT_ZOOM_ZERO - 2; }
	} else
	if ( prev < N_PAINT_ZOOM_ZERO )
	{
		if ( zoom > ( N_PAINT_ZOOM_ZERO - 2 ) ) { zoom = N_PAINT_ZOOM_ZERO + 1; }
	}


	return zoom;
}

// internal
void
n_paint_zoom_bitmap2canvas( s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	int z = n_paint_zoom_get( zoom );


	if ( n_paint_is_zoom_in( zoom ) )
	{
		if ( x  != NULL ) { (*x ) *= z; }
		if ( y  != NULL ) { (*y ) *= z; }
		if ( sx != NULL ) { (*sx) *= z; }
		if ( sy != NULL ) { (*sy) *= z; }
	} else
	if ( n_paint_is_zoom_out( zoom ) )
	{
		if ( x  != NULL ) { (*x ) /= z; }
		if ( y  != NULL ) { (*y ) /= z; }
		if ( sx != NULL ) { (*sx) /= z; }
		if ( sy != NULL ) { (*sy) /= z; }
	}


	return;
}

// internal
void
n_paint_zoom_canvas2bitmap( s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	int z = n_paint_zoom_get( zoom );


	if ( n_paint_is_zoom_out( zoom ) )
	{
		if ( x  != NULL ) { (*x ) *= z; }
		if ( y  != NULL ) { (*y ) *= z; }
		if ( sx != NULL ) { (*sx) *= z; }
		if ( sy != NULL ) { (*sy) *= z; }
	} else
	if ( n_paint_is_zoom_in( zoom ) )
	{
		if ( x  != NULL ) { (*x ) /= z; }
		if ( y  != NULL ) { (*y ) /= z; }
		if ( sx != NULL ) { (*sx) /= z; }
		if ( sy != NULL ) { (*sy) /= z; }
	}


	return;
}


// [ nonnon_paint_colorhistory.c ]

extern void n_paint_colorhistory_add( u32 );
extern LRESULT CALLBACK n_paint_colorhistory_wndproc( HWND, UINT, WPARAM, LPARAM );


// [ nonnon_paint_colorsync.c ]

static UINT n_paint_sync_wm_synccolor = WM_NULL;


extern void n_sync_go( UINT, WPARAM, LPARAM );


// [ nonnon_paint_formatter.c ]

static n_posix_char *n_paint_formatter_name;
static n_bmp        *n_paint_formatter_bmp;


// [ nonnon_paint_grabber.c ]

#define N_PAINT_GRABBER_NEUTRAL              0
#define N_PAINT_GRABBER_SELECTING            1
#define N_PAINT_GRABBER_DRAG_OK              2
#define N_PAINT_GRABBER_DRAGGING             3
#define N_PAINT_GRABBER_STRETCH_PROPORTIONAL 4
#define N_PAINT_GRABBER_STRETCH_TRANSFORM    5

#define N_PAINT_GRABBER_IS_NEUTRAL()              ( grabber == N_PAINT_GRABBER_NEUTRAL              )
#define N_PAINT_GRABBER_IS_SELECTING()            ( grabber == N_PAINT_GRABBER_SELECTING            )
#define N_PAINT_GRABBER_IS_DRAG_OK()              ( grabber == N_PAINT_GRABBER_DRAG_OK              )
#define N_PAINT_GRABBER_IS_DRAGGING()             ( grabber == N_PAINT_GRABBER_DRAGGING             )
#define N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() ( grabber == N_PAINT_GRABBER_STRETCH_PROPORTIONAL )
#define N_PAINT_GRABBER_IS_STRETCH_TRANSFORM()    ( grabber == N_PAINT_GRABBER_STRETCH_TRANSFORM    )


extern void n_paint_grabber_reset( void );
extern void n_paint_grabber_position_reset( void );


static bool n_paint_grabber_finalize_onoff = true;


// [ nonnon_paint_tool.c ]

#define N_PAINT_TOOL_TYPE_NONE  0
#define N_PAINT_TOOL_TYPE_PEN   1
#define N_PAINT_TOOL_TYPE_FILL  2
#define N_PAINT_TOOL_TYPE_GRAB  3


static n_win_colorpicker cp;
static HWND              n_paint_hpopup;


extern void n_paint_tool_saveicon_refresh( void );


u32
n_paint_tool_color_transparent_get( void )
{
	return n_bmp_white_invisible;//n_bmp_alpha_invisible_pixel( n_bmp_argb( cp.a, cp.r, cp.g, cp.b ) );
}


// [ nonnon_paint_tool_grabber.c ]

static n_win_statusbar_ownerdraw n_paint_tool_grabber_status;

static int  n_paint_tool_grabber_csy;
static bool n_paint_tool_per_pixel_alpha_onoff;
static int  n_paint_tool_blend;
static u32  n_paint_tool_color_transparent;

extern void n_paint_tool_grabber_onoff( bool );
//extern void n_paint_tool_grabber_trans_onoff( bool );
extern void n_paint_tool_grabber_blend_zero( void );
extern void n_paint_tool_grabber_resize( void );
extern void n_paint_tool_grabber_proc( HWND, UINT, WPARAM, LPARAM );

